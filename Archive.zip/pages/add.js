import React from 'react'
import AddSection from '../components/AddSection';


export const Add = () => {
  return (
    <AddSection />
  )
}
export default Add;


