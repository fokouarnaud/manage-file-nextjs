import React from 'react'
import Footer from '../components/Footer'
import Hero from '../components/Hero3'

const home = () => {
    return (
       
            <Hero/>
           
       
    )
}

export default home