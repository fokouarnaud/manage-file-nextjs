import React from 'react'

const Nav = () => {
  return (
    <div>Nav</div>
  )
}

export default Nav;